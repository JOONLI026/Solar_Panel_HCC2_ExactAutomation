import React from 'react'
import './logging.scss'

const Logging = () => {
  
  return (
    <div className="logging">
      <p className="logging-title text-bold">This page is currently out of service</p>
    </div>
  )
}

export default Logging
