exports.default = {
  type: 'application',
  details: {
    title: 'Event Manager',
    label: 'HCC2 Centralized Event Detection ',
    mainSection: 1,
    position: '1',
    id: 'eventmgr',
    url: '/eventmgr'
  },
  sections: [
    {
      details: {
        title: '',
        id: '',
        url: ''
      },
      content: [
        {
          id: '',
          layout: [{}],
          ui: {}
        }
      ]
    }
  ]
}
