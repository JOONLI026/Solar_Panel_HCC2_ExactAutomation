exports.default = {
    type: "application",
    details: {
        title: "License Manager",
        label: "HCC2 License Management Interface",
        id: "licenseManager",
        url: "/licenseManager",
    },
    sections: [
        {
            details: {
                title: "",
                id: "",
                url: "",
            },
            content: [
                {
                    id: "",
                    layout: [{}],
                    ui: {},
                },
            ],
        },
    ],
};
