exports.default = {
  type: 'application',
  details: {
    title: 'Modbus Driver',
    label: 'Modbus Server/Client Driver',
    mainSection: 1,
    position: '1',
    id: 'modbus',
    url: '/modbus'
  },
  sections: [
    {
      details: {
        title: '',
        id: '',
        url: ''
      },
      content: [
        {
          id: '',
          layout: [{}],
          ui: {}
        }
      ]
    }
  ]
}
