exports.default = {
  type: 'application',
  details: {
    title: 'IO Systems',
    label: 'IOB Manager Application',
    mainSection: 1,
    position: '1',
    id: 'iobmgr',
    url: '/iobmgr'
  },
  sections: [
    {
      details: {
        title: '',
        id: '',
        url: ''
      },
      content: [
        {
          id: '',
          layout: [{}],
          ui: {}
        }
      ]
    }
  ]
}
