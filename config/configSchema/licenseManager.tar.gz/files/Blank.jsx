import React from "react";

function MyTitle() {
    return (
        <div>
            <h3>Blank</h3>
        </div>
    );
}

export default MyTitle;
