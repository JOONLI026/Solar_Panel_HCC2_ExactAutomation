exports.default = {
    type: "application",
    details : {
        title: "avalonHcc2App",
        label: "avalonHcc2App",
        mainSection: 1,
        position: 1,
        id: "avalonHcc2App",
        url: "/avalonHcc2App"
    },
    sections: [
        {
          details: {
            title: '',
            id: '',
            url: ''
          },
          content: [
            {
              id: '',
              layout: [{}],
              ui: {}
            }
          ]
        }
    ]
}